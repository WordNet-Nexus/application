from neo4j import GraphDatabase
import os
import json

def lambda_handler(event, context):
    uri = os.environ['NEO4J_URI']
    user = os.environ['NEO4J_USER']
    password = os.environ['NEO4J_PASSWORD']

    limit = event.get('limit', 10) 
    min_length = event.get('min_length', None)
    
    try:
        limit = int(limit)
        if min_length is not None:
            min_length = int(min_length)
    except ValueError:
        return {
            "statusCode": 400,
            "body": json.dumps({"error": "Invalid input for 'limit' or 'min_length'. Must be integers."})
        }

    query = """
        MATCH (n:Word)-[r]->()
        WHERE $min_length IS NULL OR size(n.id) >= $min_length
        RETURN n.id AS node, COUNT(r) AS connections
        ORDER BY connections DESC
        LIMIT $limit
    """

    driver = GraphDatabase.driver(uri, auth=(user, password))
    with driver.session() as session:
        result = session.run(query, {"limit": limit, "min_length": min_length})
        
        top_nodes = [{"node": record["node"], "connections": record["connections"]} for record in result]
    
    driver.close()
    
    return {
        "statusCode": 200,
        "body": json.dumps(top_nodes)
    }
